package com.example.footballapp.model

import com.example.footballapp.model.match.MatchItem
import com.google.gson.annotations.SerializedName

class MatchSearchResponse (

    @field:SerializedName("event")
    val event: List<MatchItem>
)