package com.example.footballapp.model.match

import com.google.gson.annotations.SerializedName

class ResponseMatch (

    @field:SerializedName("events")
    val events: List<MatchItem>
)