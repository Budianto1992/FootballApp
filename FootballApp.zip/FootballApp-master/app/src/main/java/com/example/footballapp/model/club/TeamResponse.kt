package com.example.footballapp.model.club

data class TeamResponse (
    val teams: List<Teams>
)