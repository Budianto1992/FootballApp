package com.example.footballapp.model

data class PlayerResponse (
    val player: List<Player>
)