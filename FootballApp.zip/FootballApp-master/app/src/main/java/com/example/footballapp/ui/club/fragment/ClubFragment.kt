package com.example.footballapp.ui.club.fragment

import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.*
import androidx.core.view.isInvisible
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.footballapp.R
import com.example.footballapp.adapter.ClubAdapter
import com.example.footballapp.model.club.Teams
import com.example.footballapp.network.ApiRepository
import com.example.footballapp.presenter.club.ClubPresenter
import com.example.footballapp.presenter.club.ClubView
import com.example.footballapp.ui.club.activity.DetailClubActivity
import com.google.gson.Gson
import kotlinx.android.synthetic.main.fragment_club.*
import kotlinx.android.synthetic.main.fragment_next_match.progressBar
import kotlinx.android.synthetic.main.fragment_next_match.rvViewMatch
import kotlinx.android.synthetic.main.fragment_next_match.swipeRefresh
import org.jetbrains.anko.startActivity
import org.jetbrains.anko.support.v4.ctx
import org.jetbrains.anko.support.v4.onRefresh

class ClubFragment : Fragment(), ClubView {


    private var club: MutableList<Teams> = mutableListOf()
    private lateinit var presenter: ClubPresenter
    private lateinit var adapter: ClubAdapter
    private lateinit var leagueName: String

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        val view = inflater.inflate(R.layout.fragment_club, container, false)
        setHasOptionsMenu(true)

        return view
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        val request = ApiRepository()
        val gson = Gson()
        presenter = ClubPresenter(this, request, gson)

        val spinnerItems = resources.getStringArray(R.array.league)
        val spinnerItemsId = resources.getStringArray(R.array.id_league)
        listspinner.adapter = ArrayAdapter(ctx, android.R.layout.simple_spinner_dropdown_item, spinnerItems)

        listspinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {

            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val getLeague = listspinner.selectedItemPosition
                leagueName = spinnerItemsId[getLeague].toString()
                presenter.getTeams(leagueName)
            }

        }

        adapter = ClubAdapter(ctx, club) {
            ctx.startActivity<DetailClubActivity>(
                "teams" to it)
        }

        rvViewMatch.layoutManager = LinearLayoutManager(context)
        rvViewMatch.adapter = adapter



        swipeRefresh.onRefresh {
            presenter.getTeams(leagueName)
        }
        swipeRefresh.setColorSchemeColors(Color.CYAN, Color.BLUE, Color.YELLOW)
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        inflater.inflate(R.menu.search_menu, menu)

        val menuItem = menu.findItem(R.id.menuView)
        val searchMenu = menuItem?.actionView as SearchView

        searchMenu.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(p0: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(query: String): Boolean {
                presenter.getSearchClub(query)
                return false
            }
        })
    }

    override fun showLoading() {
        progressBar.visibility
    }

    override fun hideLoading() {
        progressBar.isInvisible
    }

    override fun showClubList(data: List<Teams>) {
        swipeRefresh.isRefreshing = false
        club.clear()
        club.addAll(data)
        adapter.notifyDataSetChanged()
    }
}