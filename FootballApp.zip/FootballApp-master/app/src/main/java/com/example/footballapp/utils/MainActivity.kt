package com.example.footballapp.utils

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.footballapp.R
import com.example.footballapp.ui.club.fragment.ClubFragment
import com.example.footballapp.ui.match.fragment.MatchFragment
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        nav_view.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.navigation_match -> {
                    loadMatchFragment(savedInstanceState)
                }

                R.id.navigation_club -> {
                    loadClubFragement(savedInstanceState)
                }
            }
            true
        }
        nav_view.selectedItemId = R.id.navigation_match
    }


    private fun loadMatchFragment(savedInstanceState: Bundle?){
        if (savedInstanceState == null) {
            supportFragmentManager
                .beginTransaction()
                .replace(R.id.main_container, MatchFragment(), MatchFragment::class.simpleName)
                .commit()

        }
    }




    private fun loadClubFragement(savedInstanceState: Bundle?) {
        if (savedInstanceState == null){
            supportFragmentManager
                .beginTransaction()
                .replace(R.id.main_container, ClubFragment(), ClubFragment::class.simpleName)
                .commit()
        }
    }
}
